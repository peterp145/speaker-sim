function RTW_SidParentMap() {
    this.sidParentMap = new Array();
    this.sidParentMap["fpga_fir_test:89:2"] = "fpga_fir_test:89";
    this.sidParentMap["fpga_fir_test:89:110"] = "fpga_fir_test:89";
    this.sidParentMap["fpga_fir_test:89:4"] = "fpga_fir_test:89";
    this.sidParentMap["fpga_fir_test:89:118"] = "fpga_fir_test:89";
    this.sidParentMap["fpga_fir_test:89:3"] = "fpga_fir_test:89";
    this.sidParentMap["fpga_fir_test:89:12"] = "fpga_fir_test:89";
    this.sidParentMap["fpga_fir_test:89:109"] = "fpga_fir_test:89";
    this.sidParentMap["fpga_fir_test:89:118:1"] = "fpga_fir_test:89:118";
    this.sidParentMap["fpga_fir_test:89:118:2"] = "fpga_fir_test:89:118";
    this.sidParentMap["fpga_fir_test:89:118:3"] = "fpga_fir_test:89:118";
    this.getParentSid = function(sid) { return this.sidParentMap[sid];}
}
    RTW_SidParentMap.instance = new RTW_SidParentMap();
