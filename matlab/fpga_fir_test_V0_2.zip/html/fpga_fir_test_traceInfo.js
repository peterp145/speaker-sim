function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <S1>/fir_filter_hdl */
	this.urlHashMap["fpga_fir_test:89:4"] = "ir_filter.vhd:105,106,107,108,109,110,111,112,113,114,115";
	/* <S1>/s_and_h */
	this.urlHashMap["fpga_fir_test:89:118"] = "ir_filter.vhd:117,118,119,120,121,122,123,124";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "fpga_fir_test"};
	this.sidHashMap["fpga_fir_test"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>/data_in"] = {sid: "fpga_fir_test:89:2"};
	this.sidHashMap["fpga_fir_test:89:2"] = {rtwname: "<S1>/data_in"};
	this.rtwnameHashMap["<S1>/data_in_valid"] = {sid: "fpga_fir_test:89:110"};
	this.sidHashMap["fpga_fir_test:89:110"] = {rtwname: "<S1>/data_in_valid"};
	this.rtwnameHashMap["<S1>/fir_filter_hdl"] = {sid: "fpga_fir_test:89:4"};
	this.sidHashMap["fpga_fir_test:89:4"] = {rtwname: "<S1>/fir_filter_hdl"};
	this.rtwnameHashMap["<S1>/s_and_h"] = {sid: "fpga_fir_test:89:118"};
	this.sidHashMap["fpga_fir_test:89:118"] = {rtwname: "<S1>/s_and_h"};
	this.rtwnameHashMap["<S1>/data_out"] = {sid: "fpga_fir_test:89:3"};
	this.sidHashMap["fpga_fir_test:89:3"] = {rtwname: "<S1>/data_out"};
	this.rtwnameHashMap["<S1>/data_out_valid"] = {sid: "fpga_fir_test:89:12"};
	this.sidHashMap["fpga_fir_test:89:12"] = {rtwname: "<S1>/data_out_valid"};
	this.rtwnameHashMap["<S1>/data_in_ready"] = {sid: "fpga_fir_test:89:109"};
	this.sidHashMap["fpga_fir_test:89:109"] = {rtwname: "<S1>/data_in_ready"};
	this.rtwnameHashMap["<S2>/In"] = {sid: "fpga_fir_test:89:118:1"};
	this.sidHashMap["fpga_fir_test:89:118:1"] = {rtwname: "<S2>/In"};
	this.rtwnameHashMap["<S2>/Trigger"] = {sid: "fpga_fir_test:89:118:2"};
	this.sidHashMap["fpga_fir_test:89:118:2"] = {rtwname: "<S2>/Trigger"};
	this.rtwnameHashMap["<S2>/ "] = {sid: "fpga_fir_test:89:118:3"};
	this.sidHashMap["fpga_fir_test:89:118:3"] = {rtwname: "<S2>/ "};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
