SLStudio.Utils.RemoveHighlighting(get_param('fpga_fir_test', 'handle'));
SLStudio.Utils.RemoveHighlighting(get_param('gm_fpga_fir_test', 'handle'));
annotate_port('gm_fpga_fir_test/ir_filter/fir_filter_hdl', 1, 1, '');
annotate_port('gm_fpga_fir_test/ir_filter/fir_filter_hdl', 1, 1, '');
annotate_port('fpga_fir_test/ir_filter/fir_filter_hdl', 1, 1, '');
annotate_port('gm_fpga_fir_test/ir_filter/fir_filter_hdl', 1, 1, '');
annotate_port('fpga_fir_test/ir_filter/fir_filter_hdl', 1, 1, '');
annotate_port('gm_fpga_fir_test/ir_filter/fir_filter_hdl_in0_buff_in_pipe', 0, 1, '');
