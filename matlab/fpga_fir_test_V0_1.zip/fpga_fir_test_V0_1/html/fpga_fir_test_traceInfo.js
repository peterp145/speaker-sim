function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <S1>/Delay */
	this.urlHashMap["fpga_fir_test:89:153"] = "ir_filter.vhd:174,175,176,177,178,179,180,181";
	/* <S1>/Delay1 */
	this.urlHashMap["fpga_fir_test:89:154"] = "ir_filter.vhd:154,155,156,157,158,159,160,161";
	/* <S1>/Delay2 */
	this.urlHashMap["fpga_fir_test:89:155"] = "ir_filter.vhd:134,135,136,137,138,139,140,141";
	/* <S1>/Discrete FIR Filter
HDL Optimized */
	this.urlHashMap["fpga_fir_test:89:4"] = "ir_filter.vhd:110,111,112,113,114,115,116,117,118,119,120,121";
	/* <S1>/Logical
Operator */
	this.urlHashMap["fpga_fir_test:89:7"] = "ir_filter.vhd:184";
	/* <S1>/s_and_h */
	this.urlHashMap["fpga_fir_test:89:118"] = "ir_filter.vhd:123,124,125,126,127,128,129,130";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "fpga_fir_test"};
	this.sidHashMap["fpga_fir_test"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>/i_rst_n"] = {sid: "fpga_fir_test:89:1"};
	this.sidHashMap["fpga_fir_test:89:1"] = {rtwname: "<S1>/i_rst_n"};
	this.rtwnameHashMap["<S1>/i_data_in"] = {sid: "fpga_fir_test:89:2"};
	this.sidHashMap["fpga_fir_test:89:2"] = {rtwname: "<S1>/i_data_in"};
	this.rtwnameHashMap["<S1>/i_data_in_valid"] = {sid: "fpga_fir_test:89:110"};
	this.sidHashMap["fpga_fir_test:89:110"] = {rtwname: "<S1>/i_data_in_valid"};
	this.rtwnameHashMap["<S1>/Delay"] = {sid: "fpga_fir_test:89:153"};
	this.sidHashMap["fpga_fir_test:89:153"] = {rtwname: "<S1>/Delay"};
	this.rtwnameHashMap["<S1>/Delay1"] = {sid: "fpga_fir_test:89:154"};
	this.sidHashMap["fpga_fir_test:89:154"] = {rtwname: "<S1>/Delay1"};
	this.rtwnameHashMap["<S1>/Delay2"] = {sid: "fpga_fir_test:89:155"};
	this.sidHashMap["fpga_fir_test:89:155"] = {rtwname: "<S1>/Delay2"};
	this.rtwnameHashMap["<S1>/Discrete FIR Filter HDL Optimized"] = {sid: "fpga_fir_test:89:4"};
	this.sidHashMap["fpga_fir_test:89:4"] = {rtwname: "<S1>/Discrete FIR Filter HDL Optimized"};
	this.rtwnameHashMap["<S1>/Logical Operator"] = {sid: "fpga_fir_test:89:7"};
	this.sidHashMap["fpga_fir_test:89:7"] = {rtwname: "<S1>/Logical Operator"};
	this.rtwnameHashMap["<S1>/s_and_h"] = {sid: "fpga_fir_test:89:118"};
	this.sidHashMap["fpga_fir_test:89:118"] = {rtwname: "<S1>/s_and_h"};
	this.rtwnameHashMap["<S1>/o_data_out"] = {sid: "fpga_fir_test:89:3"};
	this.sidHashMap["fpga_fir_test:89:3"] = {rtwname: "<S1>/o_data_out"};
	this.rtwnameHashMap["<S1>/o_data_out_valid"] = {sid: "fpga_fir_test:89:12"};
	this.sidHashMap["fpga_fir_test:89:12"] = {rtwname: "<S1>/o_data_out_valid"};
	this.rtwnameHashMap["<S1>/o_data_in_ready"] = {sid: "fpga_fir_test:89:109"};
	this.sidHashMap["fpga_fir_test:89:109"] = {rtwname: "<S1>/o_data_in_ready"};
	this.rtwnameHashMap["<S2>/In"] = {sid: "fpga_fir_test:89:118:1"};
	this.sidHashMap["fpga_fir_test:89:118:1"] = {rtwname: "<S2>/In"};
	this.rtwnameHashMap["<S2>/Trigger"] = {sid: "fpga_fir_test:89:118:2"};
	this.sidHashMap["fpga_fir_test:89:118:2"] = {rtwname: "<S2>/Trigger"};
	this.rtwnameHashMap["<S2>/ "] = {sid: "fpga_fir_test:89:118:3"};
	this.sidHashMap["fpga_fir_test:89:118:3"] = {rtwname: "<S2>/ "};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
